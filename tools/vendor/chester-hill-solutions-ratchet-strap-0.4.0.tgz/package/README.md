# RatchetStrap

<img src="assets/ratchet-strap.png" alt="A red ratchet strap securing a cardboard package" width="240" />

`@chester-hill-solutions/ratchet-strap` centralizes lint policies and tracks existing debt in each consuming repository. ESLint detects violations; RatchetStrap compares them with a checked-in baseline and records reviewed improvements. The CLI runs under Node and has no runtime dependencies.

New projects track individual diagnostic identities. Compatibility profiles preserve Callcaster, Quick Canvass, Sparkfunds Helcim and Stow TS lint contracts. One workflow covers discovery, initialization, checking, tightening, rule additions, and verified migration for recognized projects.

- [What a rule looks like](#what-a-rule-looks-like)
- [Commands](#commands)
- [Profiles and baselines](#profiles-and-baselines)
- [Using and creating shared policies](#using-and-creating-shared-policies)
- [Writing a custom rule](#writing-a-custom-rule)
- [Adopting existing projects](#adopting-existing-projects)
- [CHS adoption candidates](docs/adoption-candidates.md)
- [API](#api)
- [Verification and limits](#verification-and-limits)

## What a rule looks like

A ratcheted rule has three parts: an ESLint detector, its configuration, and a local allowance for existing debt. There is no separate RatchetStrap rule language.

For example, enable ESLint's `max-params` detector as a warning in `eslint.config.mjs`:

```js
export default [
  {
    files: ["app/**/*.{js,jsx,ts,tsx}"],
    rules: { "max-params": ["warn", { max: 5 }] },
  },
];
```

Here `max: 5` limits the parameters of each function. This function produces a warning:

```js
function sendMessage(sender, recipient, subject, body, attachments, options) {
  // ...
}
```

Taking a message object brings the function within the limit:

```js
function sendMessage(message) {
  // ...
}
```

Before repairing it, `init` can record the exact existing diagnostic:

```json
{
  "schemaVersion": 2,
  "mode": "identities",
  "adapter": "eslint-identities@1",
  "identities": {
    "max-params": [
      "app/mail.js:max-params:Function 'sendMessage' has too many parameters (6). Maximum allowed is 5.#1"
    ]
  }
}
```

The entry identifies existing debt. It does not change the five-parameter limit.

| Change | Strict identity result |
| --- | --- |
| Another function violates the rule | `check` fails with a new identity |
| The recorded function is repaired | `check` fails with a stale entry ready to remove |
| Preview `tighten`, then run it with `--write` | The repaired identity is removed; the gate passes |
| The rule has no remaining violations | Its tracked entry remains as `"max-params": []` |
| A later function introduces debt | The new identity fails the gate |

Use `"warn"` for debt you want to ratchet. Use `"error"` for a requirement that must always pass: unsuppressed ESLint errors fail regardless of the baseline. The legacy count profiles allow improvements to pass before their counts are explicitly tightened.

## Commands

After publication, install from [GitHub Packages](../../docs/USING-PACKAGES.md):

```bash
bun add --dev @chester-hill-solutions/ratchet-strap
```

During development, build this package and substitute `node /path/to/chester-hill-solutions/packages/ratchet-strap/dist/cli.js` for `ratchet-strap`.

For a new project, enable its intended ESLint rules first, then:

```bash
ratchet-strap rules
ratchet-strap profiles
ratchet-strap init --rules no-console,complexity --exec-eslint
ratchet-strap inspect
ratchet-strap check --exec-eslint

# After repairing existing debt:
ratchet-strap tighten --exec-eslint         # preview
ratchet-strap tighten --exec-eslint --write # remove repaired entries

# After enabling an additional ESLint rule:
ratchet-strap add --rules no-alert --exec-eslint
ratchet-strap add --rules no-alert --exec-eslint --write
```

`--root DIR` selects the consuming repository; relative paths resolve from it. The default baseline is `.ratchet-strap.json`, configurable with `--baseline FILE`. `init` creates a new baseline from an explicit rule list and refuses overwrite. Use [migration](#adopting-existing-projects) when a repository already has a ratchet.

Commands return JSON. Exit codes: **0** success, **1** violations, **2** invalid input or tool failure. `check` never writes. `tighten` and `add` preview by default; `--write` saves their proposed baseline. A successful tightening preview can have `checkOk: false` because the original baseline still has stale entries.

### Reuse an existing lint report

```bash
eslint . --format json --no-cache --output-file eslint-report.json
ratchet-strap check --report eslint-report.json
```

`--report FILE` and `--exec-eslint` are mutually exclusive. Report default: `eslint-report.json`. The runner uses the consumer's installed ESLint with `.` as its scope and JSON output; it never downloads ESLint. Generic profiles disable caching by default. Compatibility profiles retain their existing cache locations.

For projects with explicit lint configuration/cache settings:

```bash
ratchet-strap check --exec-eslint \
  --eslint-config eslint.ci.config.mjs \
  --cache-location node_modules/.cache/eslint
```

Those runner flags require `--exec-eslint`. Keep the application's existing scan scope, configuration, and detector versions during adoption; externally generated reports can retain its exact lint invocation.

## Profiles and baselines

A **policy** supplies ESLint rules/options. An **adapter** translates detector output. A **profile** selects a comparison mode, adapter, and runner defaults. The **baseline** stores the consuming repository's accepted existing debt. Their versions are separate.

| Profile | Adapter | Comparison | Runner defaults |
| --- | --- | --- | --- |
| `eslint@1` (default) | `eslint-identities@1` | New and stale identities fail | Consumer config, no cache |
| `eslint-counts@1` | `eslint-json@1` | Per-rule warning counts cannot grow | Consumer config, no cache |
| `callcaster@1` | `callcaster-lint@1` | Original warning/directive counts | Consumer config, shared ESLint cache |
| `quick-canvass@1` | `quick-canvass-lint@1` | Original identities plus import cycles | `eslint.config.mjs`, original cache, predecessor lookup |
| `sparkfunds-helcim@1` | `sparkfunds-helcim-lint@1` | Seven message counts; retain preceding lint gate | Fixed `npx eslint -f json .`, no cache |
| `stow@1` | `stow-lint@1` | Growth and stale counts fail; required Git predecessor | Fixed `packages/stow-s3` scope, no cache; manual adoption |

An explicit count baseline remains supported:

```bash
ratchet-strap init --profile eslint-counts@1 \
  --rules no-console,complexity --exec-eslint
```

```json
{
  "schemaVersion": 1,
  "adapter": "eslint-json@1",
  "counts": { "no-console": 3, "complexity": 0 }
}
```

Schema 1 remains compatible with the original RatchetStrap count API. Schema 2 records identities. Baselines pin their adapter, so `check` and `tighten` infer their profile without repeating flags. Unknown versions and mixed modes fail; there is no implicit conversion from identities to counts.

### Identity behavior and limits

Current identities use **relative file, rule ID, diagnostic message, and occurrence number**. Suppressed messages participate in the same numbering sequence. Line/column remain available in diagnostics but do not form the identity, so moving unchanged code within its file does not invalidate a baseline.

This detects substitutions across files or diagnostic messages. It cannot distinguish removal and replacement of the same rule/message occurrence within one file. Renames, changes to message text, and diagnostic ordering may also require a reviewed migration. These are diagnostic identities, not semantic source identities.

Count profiles additionally permit one removed violation to offset a new violation of the same rule anywhere in the lint scope. Choose them to retain an existing count contract deliberately.

### Suppressions and hard errors

The generic adapters, Quick Canvass and Stow consume explicit `suppressedMessages` arrays from the [ESLint JSON formatter](https://eslint.org/docs/latest/use/formatters/#json). Suppressed tracked diagnostics remain debt, including suppressed errors. These adapters reject unsuppressed severity-2 diagnostics, including untracked rules.

`callcaster-lint@1` retains the original suppression-comment expression and ignores suppression metadata to avoid double counting. This includes its original limits: first captured rule per match, wildcard disables excluded, and original multiline behavior. Those semantics are frozen; improving them requires another adapter version.

`sparkfunds-helcim-lint@1` preserves the original seven tracked message counts regardless of severity. Suppressions and unrelated hard errors are ignored by that legacy ratchet. Keep its separate preceding `npm run lint` gate. Verified application additionally requires the lint report to have no hard errors. Invalid reports and execution failures fail closed rather than reproducing the old checker's empty-report fallback. Its `{}` baseline imports as seven explicit zero budgets; initialization cannot absorb measured debt.

### Baseline growth and writes

All profiles support `--previous-baseline FILE` to reject newly allowed debt relative to an explicitly supplied versioned predecessor. For identities this checks set membership, including replacements with the same count. Count predecessors enforce non-increasing budgets. Adapter, mode, and tracked-rule changes require a separate reviewed migration.

Quick Canvass automatically reads `HEAD^` for the versioned baseline, falling back during first adoption to the original `scripts/baselines/lint-ratchet.json` or `--legacy-baseline FILE`. Malformed/unsupported predecessor formats fail closed; legacy-version mismatches require review. With no Git parent or predecessor file, historical comparison is unavailable and the JSON output records that state. Ordinary lint checks still run. Generic profiles require an explicit predecessor argument for historical baseline protection.

Fetch the required parent history in CI or supply a trusted `--previous-baseline` file. A `no-history` result does not establish historical non-regression.

Stow requires a resolvable `--base-ref REF`, `STOW_BASELINE_REF`, or default `HEAD^`; missing history is an error. It checks the migrated baseline at that ref, falling back to the legacy path only when the new file is absent. Malformed migrated history fails closed. The legacy helper's historical malformed-JSON/absent-file fallback is retained. Stow also rejects stale count budgets; `tighten` can record improvements while refusing growth. Its fixed scope and history rules require importing the existing baseline, not initializing a new one.

Baseline writes preserve comments and tracked zero rules. They use a cooperative lock, unchanged-input check, temporary file, and atomic replacement. Imports never overwrite an existing file. If an interrupted process leaves a `.lock`, confirm the writer has stopped before removing it.

## Using and creating shared policies

### Use the existing quality policy

Import the versioned quality policy into an ESLint flat config. Supply the TypeScript plugin using the application's existing setup:

```js
import { eslintQualityRulesV1 } from "@chester-hill-solutions/ratchet-strap";

export default [
  // Existing parser, plugin registrations, ignores, and application rules…
  {
    files: ["app/**/*.{js,jsx,ts,tsx}"],
    rules: { ...eslintQualityRulesV1 },
  },
];
```

`chs-quality@1` preserves Callcaster's generic warning thresholds: complexity 20, depth 4, parameters 5, function size 200 excluding blanks/comments, and warnings for console calls, return-await, and non-null assertions. The preset does not install plugins or choose application-specific scopes and exemptions. Shadcn rules remain configured by the consumer and can be budgeted by either adapter.

The canonical record lives in `@chester-hill-solutions/eslint-config/ratchet-rules`. This package embeds that record at build time and retains `eslintQualityRulesV1` as its public alias. The compiled Node CLI has no runtime dependency on ESLint-config or its plugins.

The named V1 policy is a stable contract. Introduce a new version for behavior changes, compare old/new full reports, and review configuration changes separately from tightening debt budgets. Automatic rule upgrades and an upgrade-diff command are not implemented in this release.

### Compose a project policy

Reuse existing ESLint or plugin rules before writing another detector. For example, a project can add a warning for browser alerts while retaining the shared policy:

```js
import { eslintQualityRulesV1 } from "@chester-hill-solutions/ratchet-strap";

const projectRulesV1 = {
  ...eslintQualityRulesV1,
  "no-alert": "warn",
};

export default [
  // Existing parser, TypeScript plugin registration, ignores, and file scopes…
  { files: ["app/**/*.{js,jsx,ts,tsx}"], rules: projectRulesV1 },
];
```

Enabling a rule in ESLint does not automatically add it to an existing baseline. After enabling it as a warning, measure and review its initial debt:

```bash
ratchet-strap add --rules no-alert --exec-eslint         # preview
ratchet-strap add --rules no-alert --exec-eslint --write # accept this new rule's initial debt
```

`add` preserves every existing allowance, including zero rules. It requires the current gate to pass and refuses already-tracked rule IDs. It measures only the new rule's initial allowance; it cannot absorb an existing regression or silently tighten another rule. New rules are allowed on the generic `eslint@1` and `eslint-counts@1` profiles. Compatibility profiles retain their frozen contracts.

### Contribute a shared policy

When at least two projects need the same policy, move its generic ESLint configuration into `packages/eslint-config`. Application-specific scopes, exemptions, and business rules stay in the consumer. RatchetStrap owns baseline comparison and compatibility adapters.

1. Add a versioned policy module under `packages/eslint-config/src/`; keep pure rule records independent of plugin initialization.
2. Export its canonical record from ESLint-config. If RatchetStrap exposes an alias, import that record in `src/policies.ts` and add it to the `rules` catalog; do not copy its thresholds.
3. Document its exact rule IDs, options, required plugins, and examples of compliant and violating code.
4. Introduce a new policy version when thresholds, tracked rules, or detection behavior change. Retain previous named versions during adoption.
5. Run the package's typecheck, tests, and build. Add focused detector tests when introducing detection logic; consuming projects keep their existing checks.

Changing a function-size threshold from 200 to 150 belongs in a new policy version. Repairing functions and lowering their budget from 12 to 9 belongs in the consuming repository's baseline. Review those changes separately.

The current baseline pins its **adapter**, not a policy/configuration fingerprint. A package lockfile and reviewed configuration changes are still required to control detector upgrades.

## Writing a custom rule

If an existing rule does not express the requirement, create an ordinary ESLint rule and register it as a local plugin. RatchetStrap consumes the resulting diagnostics using the same rule ID. The structure follows ESLint's [custom rule API](https://eslint.org/docs/latest/extend/custom-rules) and [local plugin configuration](https://eslint.org/docs/latest/use/configure/plugins#configure-a-local-plugin).

This example requires an issue reference on TODO comments. Put it in the consuming repository's `eslint-rules/todo-issue.mjs`:

```js
// eslint-rules/todo-issue.mjs
export default {
  meta: {
    type: "suggestion",
    docs: { description: "Require an issue reference on TODO comments" },
    schema: [],
    messages: {
      missingIssue: "Use TODO(CHS-123): followed by the planned change.",
    },
  },
  create(context) {
    return {
      Program() {
        for (const comment of context.sourceCode.getAllComments()) {
          const missingIssue = /\bTODO\b(?!\([A-Z][A-Z0-9]*-\d+\):)/;
          if (missingIssue.test(comment.value)) {
            context.report({ loc: comment.loc, messageId: "missingIssue" });
          }
        }
      },
    };
  },
};
```

`meta` describes the diagnostic and accepted options; `create` supplies AST visitors; `context.report` emits a diagnostic. This example reports once per comment containing an unqualified TODO. It checks source comments, so a string containing `"TODO"` is not a violation.

Register and enable it in `eslint.config.mjs`, retaining the application's other configuration entries:

```js
// eslint.config.mjs
import todoIssue from "./eslint-rules/todo-issue.mjs";

export default [
  {
    files: ["app/**/*.{js,jsx,ts,tsx}"],
    plugins: {
      local: { rules: { "todo-issue": todoIssue } },
    },
    rules: { "local/todo-issue": "warn" },
  },
];
```

The plugin key `local` plus the rule key `todo-issue` gives the full ID **`local/todo-issue`**. Use that exact ID in the baseline.

```js
// Violating: TODO: replace the fallback.
// Compliant: TODO(CHS-123): replace the fallback.
const label = "TODO"; // Compliant: the marker is inside a string.
```

For a new repository, initialize and run the rule through RatchetStrap:

```bash
ratchet-strap init --rules local/todo-issue --exec-eslint
ratchet-strap check --exec-eslint
# Repair the unqualified comments, then record the improvement:
ratchet-strap tighten --exec-eslint --write
```

For an existing generic-profile baseline, use `ratchet-strap add --rules local/todo-issue --exec-eslint`, review its initial debt, and rerun with `--write`. The TODO example is documentation, not a detector bundled with RatchetStrap. If shared by multiple projects, publish its implementation through a shared ESLint plugin and version it alongside its policy.

## Adopting existing projects

Discovery recognizes a checker by its frozen source fingerprint **and** supported baseline shape. A familiar filename alone does not establish compatibility.

```bash
# Run inside Callcaster, Quick Canvass or Sparkfunds Helcim:
ratchet-strap detect
ratchet-strap migrate                     # preview a recognized project
ratchet-strap verify --exec-eslint        # compare old/new on one scan
ratchet-strap migrate --apply --exec-eslint # verify again, then adopt
```

`migrate` returns the imported baseline, proposed package-script replacements, recognition status, and adoption notes. It preserves simple script aliases and proposes their original config/cache options. Compound/custom commands are left for manual review. Preview and baseline-only `--write` never edit scripts. Explicit `--apply` verifies first, then creates the imported baseline and replaces only the proposed aliases in `package.json`. CI can keep calling the same script names. The original checker and legacy baseline remain available.

You can also select a supported format explicitly:

```bash
ratchet-strap migrate --profile callcaster@1 \
  --from scripts/baselines/lint-ratchet.json
ratchet-strap migrate --profile quick-canvass@1 \
  --from scripts/baselines/lint-ratchet.json
ratchet-strap migrate --profile sparkfunds-helcim@1 \
  --from scripts/baselines/lint-ratchet.json
```

Unknown checker fingerprints are reported as unverified even when their baseline can be imported. Import success does not establish full-project parity.

For baseline-only import without changing scripts:

```bash
ratchet-strap import-callcaster --from scripts/baselines/lint-ratchet.json
ratchet-strap import-quick-canvass --from scripts/baselines/lint-ratchet.json
ratchet-strap import-helcim --from scripts/baselines/lint-ratchet.json
```

These are alternatives to baseline-only `migrate --write`. Existing targets are never overwritten. Choose verified `--apply` directly when adopting scripts; do not first create its target with `--write` or an import command.

### Stow TS lint

Stow has a supported lint adapter and importer, but no automatic `verify`/`migrate --apply` path. Its checker also depends on project-owned helper files and nested package scripts. Compare the original/new gates before manually switching those aliases:

```bash
# From the Stow repository root:
ratchet-strap import-stow --from scripts/baselines/lint-ratchet.json \
  --baseline .ratchet-strap-stow.json
ratchet-strap check --baseline .ratchet-strap-stow.json --exec-eslint
ratchet-strap tighten --baseline .ratchet-strap-stow.json --exec-eslint
ratchet-strap tighten --baseline .ratchet-strap-stow.json --exec-eslint --write
```

The runner executes inside `packages/stow-s3`. Nested package scripts should pass `--root ../..`. Retain the original checker and baseline during review; keep Go, coverage, type-escape, file-size and duplication gates. The new baseline writer only tightens; it does not reproduce the legacy writer's ability to raise budgets.

### Verify compatibility

```bash
ratchet-strap verify --exec-eslint
# Or reuse an explicit, fresh report from the existing lint command:
ratchet-strap verify --report eslint-report.json
```

Verification uses the recognized profile's fixed ESLint invocation. Generic, Callcaster and Quick Canvass ordinary checks accept config/cache overrides; Helcim and Stow always retain their fixed invocations. It executes an immutable copy of the exact recognized original checker. Its known ESLint invocation receives the same report used by RatchetStrap, so the comparison does not run lint a second time. A separate measurement pass uses only a scratch baseline. Original project files are not written. Quick Canvass's normal gate retains its actual Git predecessor check; the measurement-only pass reads no predecessor so it can expose the current observations independently.

Externally supplied reports must come from the canonical invocation and intended scope. Verification compares the supplied diagnostics; it does not attest an external report's producer or completeness. Use `--exec-eslint` to generate that scan through the fixed profile.

The JSON result reports `equivalent`, `canApply`, the legacy/current gate outcomes, observed counts/identities, and differences. Agreement on a failing gate returns exit **1** and cannot authorize application. Unknown checkers, invalid reports, or a custom legacy source path return exit **2**. Automatic verification supports the original hardcoded `scripts/baselines/lint-ratchet.json` source; other supported files remain available for preview/import.

### Apply a verified migration

Install the same RatchetStrap version as a declared dependency in the consuming repository before applying. For an unpublished candidate, install its reviewed packed tarball as a development dependency; the source-checkout CLI can still preview/verify before installation.

```bash
npm install --save-dev /absolute/path/chester-hill-solutions-ratchet-strap-0.4.0.tgz
```

```bash
ratchet-strap --version
ratchet-strap migrate --apply --exec-eslint
```

Apply requires equivalent **passing** gates and validates the declared/installed package version and the executable npm will actually resolve. It checks that the checker, manifest, legacy baseline, config/lock files, scanned source bytes, project-file membership, Quick Canvass cycle membership, and available Git HEAD still match verification. It recomputes script suggestions, retains unrelated manifest fields and dependency metadata, and uses a cooperative project lock with exclusive baseline creation and atomic manifest replacement. If the manifest commit fails, its unchanged newly created baseline is removed. This is an ordinary filesystem transaction; a process crash between its two file commits can require recovery from the retained legacy files.

Project membership checks are conservative: added or removed files require fresh verification, even when the change is unrelated to lint. Git/dependency internals, the known cache output, and owned migration files are excluded.

`--apply` and `--write` are mutually exclusive. Apply requires `--exec-eslint` or an explicit fresh `--report FILE`; it never installs dependencies or publishes a package. Existing targets, stale inputs, or a failed comparison leave application blocked. Review the resulting diff and run the existing CI entry point before committing adoption.

Quick Canvass imports retain all eight tracked rules, every identity, and their legacy version (supported versions: 2 and 4). Its supplemental cycle scan preserves the original traversal and identity spelling, with source reads restricted to the selected root. Verification additionally refuses symlinked cycle sources/directories so snapshot membership is unambiguous. The traversal's existing performance characteristics remain.

Before adopting the suggested scripts, compare old and new gates on the same source tree and fresh reports. Check identities/counts, pass/fail outcomes, suppressions, cycle results, and predecessor behavior. Keep the original check and baseline available while reviewing the switch. The proposed baseline writer deliberately allows tightening only.

| Check | Product support | Evidence / remaining adoption work |
| --- | --- | --- |
| Callcaster lint | Count profile, verification, and guarded application | Fresh original/new comparison: 2,420 files and all 1,467 observed counts matched |
| Quick Canvass lint | Identity/cycle profile, verification, and guarded application | Exact-lock isolated checkout: 1,774 files and all 918 identities matched the original checker |
| Effects / async waterfalls | Retain existing checks | Per-file/symbol keys and generated inventories need dedicated adapters |
| Duplication | Retain existing check | Coarse/fine metrics require independent ceilings |
| Coverage | Retain existing floor ratchet | Thresholds increase; current debt allowances decrease |

The original [Callcaster checker](https://github.com/chester-hill-solutions/callcaster/blob/91c4409b28321504eb07f169801542a61ed7d4a8/scripts/check-lint-ratchet.mjs) and captured Quick Canvass checker are preserved as test fixtures. No automatic detector upgrade, configuration fingerprint enforcement, remote rule registry, or arbitrary adapter plugin loader is implemented.

## API

The common API dispatches by the baseline's comparison mode:

```ts
import {
  parseRatchetBaseline, observeBaseline, checkBaseline, tightenBaseline,
} from "@chester-hill-solutions/ratchet-strap";

const baseline = parseRatchetBaseline(savedJson);
const observed = observeBaseline(baseline, eslintReport, process.cwd());
const result = checkBaseline(baseline, observed);
const proposed = result.canTighten ? tightenBaseline(baseline, observed) : undefined;
```

Pass an optional versioned predecessor as the third argument to `checkBaseline` / `tightenBaseline`. Library calls do not perform automatic Git lookup; that belongs to the Quick Canvass and Stow CLI workflows. `addRules` returns a proposal preserving existing allowances. `profiles`, `detectProjects`, and `planMigration` support structured discovery/adoption. `verifyMigration` returns a fingerprint-bound comparison result; `applyMigration` checks its freshness and performs the guarded file update. Their exported `MigrationVerification` type is a local workflow result, not a signed authorization token.

The original count-specific `parseBaseline`, `summarize`, `evaluate`, and `tighten` exports remain available. Identity-specific APIs and public types are also exported; the common API is the usual entry point.

## Verification and limits

```bash
bun run --cwd packages/ratchet-strap typecheck
bun run --cwd packages/ratchet-strap test
bun run --cwd packages/ratchet-strap build
```

Compatibility tests execute the frozen original checkers on matching reports/source fixtures, including new/stale identities, count regressions, suppressions, cycles, and predecessor cases. CLI tests cover preview/write behavior, safe rule additions, legacy imports, and historical allowance protection. Release verification packs the artifact and runs it under Node from an isolated consuming-project fixture.

The [Callcaster validation record](docs/callcaster-validation.md) records the real-tree comparison and root-check limitations. Quick Canvass fixture provenance is in `fixtures/quick-canvass-provenance.json`; full-tree comparison now also passes in an exact-lock isolated checkout. Current results are in the verified adoption record. The [consolidation record](docs/product-plan.md) captures the initial product decisions; the [verified adoption record](docs/verified-adoption.md) tracks the 0.3.0 workflow and current verification evidence.

Empty reports, duplicate file results, malformed messages, and inconsistent totals fail closed. RatchetStrap cannot prove that an externally supplied report covers the entire repository or that every tracked ESLint rule is enabled. CI must produce fresh reports with the intended configuration and scope. Pin ESLint/plugin versions in the consumer's lockfile and review rule upgrades separately from debt tightening.

The original Rapid Strap ZIP supplied the prototype. RatchetStrap builds on Callcaster and Quick Canvass's existing contracts. Publication remains a separate release step. Automatic consumer script changes require verified `migrate --apply`; other integrations require a reviewed manual patch.
